﻿# MDMIS Project Handover

## Project
MDMIS — Disaster Management Information System.

## Current local folder
C:\Users\sheke\MDMIS

## Current status
- Frontend: index.html and style.css.
- Backend: app.py using Flask.
- Supabase JavaScript client is loaded by index.html.
- Supabase configuration is stored in supabase-config.js.
- supabase-test.js checks the Supabase connection.
- A successful Supabase connection and published-advisory read were previously confirmed.
- The frontend still contains sample data. Replacing the advisory sample cards with live Supabase records is the next planned programming task.

## Important files
- index.html — main website.
- style.css — website styling.
- app.py — Flask health-check backend.
- supabase-config.js — Supabase URL and publishable key. Keep private.
- supabase-test.js — Supabase connection test.
- index-backup*.html — previous HTML versions.
- .git — local Git history.

## Python environment
The old .venv folder was excluded from the transfer ZIP. Re-create the environment on the new laptop instead of copying it.

Previously used:
- Python 3.12.10
- Flask
- Backend health endpoint: http://127.0.0.1:5000/api/health

## Supabase cloud project
Project URL:
https://hyczrepxvqcsaxytalso.supabase.co

Tables already created in Supabase:
- advisories
- evacuation_centers
- hotlines
- profiles

Row Level Security (RLS) is enabled. Public users can read published content. Authenticated users have permissions controlled by profile roles and section-management flags.

An administrator authentication account and administrator profile were previously configured. Do not recreate accounts or modify policies without checking the existing cloud project first.

## Next steps on the new laptop
1. Extract MDMIS-transfer.zip into the user's home folder so the project is at C:\Users\sheke\MDMIS (the Windows username may differ on the new laptop).
2. Inspect the extracted files and Git status.
3. Install or verify Python.
4. Create a new virtual environment and install Flask.
5. Start the backend and test /api/health.
6. Open the website and re-test Supabase connectivity.
7. Continue by loading published advisories from Supabase instead of hardcoded sample cards.
8. Save the existing Supabase SQL schema and security policies in separate .sql files for future recovery.

## Backup and security notes
- The transfer ZIP contains local source code and Git history, but does not back up the live Supabase database or authentication accounts.
- Keep supabase-config.js and the ZIP private.
- Never put a Supabase service-role key in browser JavaScript.
- Do not run git reset, git clean, or destructive database commands during recovery.
- Inspect Git status before making changes.
