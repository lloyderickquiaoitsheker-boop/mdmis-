
const SUPABASE_URL = "https://hyczrepxvqcsaxytalso.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_WqQmQKYNmZj2gzOzlTEzLQ_WgsgXJ4o";
