
from flask import Flask, jsonify

app = Flask(__name__)


@app.route("/api/health")
def health_check():
    return jsonify({
        "status": "ok",
        "application": "MDMIS",
        "message": "Backend is running."
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
