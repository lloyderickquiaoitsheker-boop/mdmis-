
(async function () {
    const output = document.getElementById("supabase-status");

    if (!output) {
        console.error("MDMIS: Status display element not found.");
        return;
    }

    if (!window.supabase || typeof window.supabase.createClient !== "function") {
        output.textContent = "Supabase library failed to load.";
        return;
    }

    if (
        typeof SUPABASE_URL === "undefined" ||
        typeof SUPABASE_PUBLISHABLE_KEY === "undefined" ||
        SUPABASE_PUBLISHABLE_KEY.startsWith("PASTE_")
    ) {
        output.textContent = "Supabase configuration needs checking.";
        return;
    }

    try {
        const client = window.supabase.createClient(
            SUPABASE_URL,
            SUPABASE_PUBLISHABLE_KEY
        );

        const { error } = await client
            .from("advisories")
            .select("id")
            .eq("is_published", true)
            .limit(1);

        if (error) {
            output.textContent = "Database check failed. See browser console.";
            console.error("MDMIS Supabase check:", error.message);
            return;
        }

        output.textContent = "Supabase connection successful.";
    } catch (error) {
        output.textContent = "Connection test failed. See browser console.";
        console.error("MDMIS connection test:", error);
    }
})();
